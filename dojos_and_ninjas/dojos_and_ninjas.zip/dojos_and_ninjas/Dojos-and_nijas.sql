SELECT * FROM dojos;
INSERT INTO dojos(name) VALUES ("TOM");
SELECT * FROM ninjas;